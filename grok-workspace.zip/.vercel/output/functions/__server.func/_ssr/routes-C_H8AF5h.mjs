import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Check, i as PenLine, n as Share2, r as Printer } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C_H8AF5h.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DETAIL_AWAL = {
	penerima: "",
	waktu: "06.00 pagi",
	tempat: "SMKS SAMUDRA",
	instansi: ""
};
var ACARA = {
	judul: "Praktik Nikah",
	hari: "Kamis",
	tanggal: "5 November 2026",
	iso: "2026-11-05",
	nomor: "01/UND-PN/XI/2026"
};
var KELOMPOK = [
	{
		judul: "Petugas akad",
		baris: [
			{
				peran: "Bapak Penghulu",
				nama: "Johana Saputra",
				kelas: "XII TKR 2",
				jurusan: "Teknik Kendaraan Ringan"
			},
			{
				peran: "Bapak pihak pria",
				nama: "Sigit",
				kelas: "XII TKJ 3",
				jurusan: "Teknik Komputer dan Jaringan"
			},
			{
				peran: "Ibu pihak pria",
				nama: "Dela Aulia",
				kelas: "XII Akuntansi",
				jurusan: "Akuntansi"
			},
			{
				peran: "Bapak pihak wanita",
				nama: "Ihsan",
				kelas: "XII TKR 2",
				jurusan: "Teknik Kendaraan Ringan"
			},
			{
				peran: "Ibu pihak wanita",
				nama: "Tiara Wiraguna",
				kelas: "XII TKJ 3",
				jurusan: "Teknik Komputer dan Jaringan"
			},
			{
				peran: "Saksi",
				nama: "Muhyi",
				kelas: "XII TKR 2",
				jurusan: "Teknik Kendaraan Ringan"
			},
			{
				peran: "Saksi",
				nama: "Parel",
				kelas: "XII TKJ 3",
				jurusan: "Teknik Komputer dan Jaringan"
			}
		]
	},
	{
		judul: "Petugas acara",
		baris: [
			{
				peran: "Sambutan pihak wanita",
				nama: "Rehan",
				kelas: null
			},
			{
				peran: "Sambutan pihak pria",
				nama: "Rangga",
				kelas: "XII TKR 1",
				jurusan: "Teknik Kendaraan Ringan"
			},
			{
				peran: "MC",
				nama: "Shela",
				kelas: "XII AK",
				jurusan: "Akuntansi"
			},
			{
				peran: "MC",
				nama: "Aril",
				kelas: "XII TKJ 1",
				jurusan: "Teknik Komputer dan Jaringan"
			},
			{
				peran: "Qoriah",
				nama: "Asyad",
				kelas: "XII TKJ 1",
				jurusan: "Teknik Komputer dan Jaringan"
			},
			{
				peran: "Sungkem",
				nama: "",
				kelas: null,
				kosong: true
			}
		]
	},
	{
		judul: "Panitia",
		baris: [
			{
				peran: "Ketua",
				nama: "Johana Saputra",
				kelas: "XII TKR 2",
				jurusan: "Teknik Kendaraan Ringan"
			},
			{
				peran: "Wakil Ketua",
				nama: "Dela Amelia",
				kelas: null
			},
			{
				peran: "Sekretaris",
				nama: "Ezra",
				kelas: "XII TKJ 1",
				jurusan: "Teknik Komputer dan Jaringan"
			},
			{
				peran: "Sekretaris",
				nama: "Aril",
				kelas: "XII TKJ 1",
				jurusan: "Teknik Komputer dan Jaringan"
			},
			{
				peran: "Bendahara",
				nama: "Ane",
				kelas: null
			},
			{
				peran: "Bendahara",
				nama: "Salsa",
				kelas: null
			}
		]
	},
	{
		judul: "Seksi",
		baris: [
			{
				peran: "Seksi acara",
				nama: "XII AK",
				kelas: null,
				jurusan: "Akuntansi"
			},
			{
				peran: "Seksi kesenian",
				nama: "XII TKJ 1",
				kelas: null,
				jurusan: "Teknik Komputer dan Jaringan"
			},
			{
				peran: "Seksi peralatan hantaran",
				nama: "XII TKJ 3",
				kelas: null,
				jurusan: "Teknik Komputer dan Jaringan"
			},
			{
				peran: "Seksi logistik",
				nama: "XII TKR 1 dan 2",
				kelas: null,
				jurusan: "Teknik Kendaraan Ringan"
			},
			{
				peran: "Seksi konsumsi",
				nama: "XII TKJ 2",
				kelas: null,
				jurusan: "Teknik Komputer dan Jaringan"
			}
		]
	}
];
var PENYIMPANAN = "undangan-praktik-nikah";
function muatDetail() {
	try {
		const mentah = localStorage.getItem(PENYIMPANAN);
		if (!mentah) return DETAIL_AWAL;
		const data = JSON.parse(mentah);
		return {
			penerima: typeof data.penerima === "string" ? data.penerima : "",
			waktu: typeof data.waktu === "string" && data.waktu.trim() ? data.waktu : DETAIL_AWAL.waktu,
			tempat: typeof data.tempat === "string" && data.tempat.trim() ? data.tempat : DETAIL_AWAL.tempat,
			instansi: typeof data.instansi === "string" ? data.instansi : ""
		};
	} catch {
		return DETAIL_AWAL;
	}
}
function simpanDetail(detail) {
	localStorage.setItem(PENYIMPANAN, JSON.stringify(detail));
}
function tampilPenerima(detail) {
	return detail.penerima.trim() || "Bapak/Ibu/Saudara/i";
}
function tampilWaktu(detail) {
	return detail.waktu.trim() || "Menyusul";
}
function tampilTempat(detail) {
	return detail.tempat.trim() || "Menyusul";
}
function buatTeks(detail) {
	const instansi = detail.instansi.trim();
	return [
		"بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
		"",
		"SURAT UNDANGAN",
		"Praktik Nikah",
		`Nomor: ${ACARA.nomor}`,
		...instansi ? ["", instansi] : [],
		"",
		"Assalamu'alaikum warahmatullahi wabarakatuh.",
		"",
		"Kepada Yth.",
		tampilPenerima(detail),
		"di tempat",
		"",
		"Dengan hormat,",
		"Kami panitia mengundang Bapak/Ibu/Saudara/i untuk menghadiri acara Praktik Nikah yang insya Allah dilaksanakan pada:",
		"",
		`Hari, tanggal : ${ACARA.hari}, ${ACARA.tanggal}`,
		`Waktu         : ${tampilWaktu(detail)}`,
		`Tempat        : ${tampilTempat(detail)}`,
		"Acara         : Praktik Nikah",
		"",
		"Kehadiran Bapak/Ibu/Saudara/i sangat kami nantikan.",
		"Demikian undangan ini kami sampaikan. Atas perhatian dan kehadirannya, kami ucapkan terima kasih.",
		"",
		"Wassalamu'alaikum warahmatullahi wabarakatuh.",
		"",
		"Hormat kami,",
		instansi || "Panitia Praktik Nikah",
		"",
		"Ketua",
		"Johana Saputra",
		"XII TKR 2",
		"",
		"Sekretaris",
		"Ezra dan Aril"
	].join("\n");
}
function hariMenuju(iso) {
	const [tahun, bulan, hari] = iso.split("-").map(Number);
	const tujuan = new Date(tahun, bulan - 1, hari);
	const kini = /* @__PURE__ */ new Date();
	const hariIni = new Date(kini.getFullYear(), kini.getMonth(), kini.getDate());
	return Math.round((tujuan.getTime() - hariIni.getTime()) / 864e5);
}
function Khatam() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		className: "size-4 shrink-0",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.2",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "6.2",
			y: "6.2",
			width: "11.6",
			height: "11.6"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "6.2",
			y: "6.2",
			width: "11.6",
			height: "11.6",
			transform: "rotate(45 12 12)"
		})]
	});
}
function Garis() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 text-gold",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-gold/60" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Khatam, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-gold/60" })
		]
	});
}
function Bingkai({ children, id }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		id,
		className: "sheet mx-auto w-full max-w-2xl text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "m-2.5 border border-gold/70 sm:m-3.5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-1.5 my-1.5 px-5 py-8 sm:px-12 sm:py-12",
				children
			})
		})
	});
}
function Surat({ detail }) {
	const instansi = detail.instansi.trim();
	const penerimaKosong = detail.penerima.trim() === "";
	const waktuKosong = detail.waktu.trim() === "";
	const tempatKosong = detail.tempat.trim() === "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Bingkai, { children: [
		instansi ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-center text-sm tracking-crest uppercase",
			children: instansi
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			dir: "rtl",
			className: "mt-2 text-center font-arabic text-3xl leading-relaxed text-balance sm:text-4xl",
			children: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Garis, {})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-center text-sm tracking-crest uppercase",
			children: "Surat Undangan"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-center text-sm text-ink/60",
			children: ["Nomor ", ACARA.nomor]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-4 text-center text-5xl leading-none text-balance italic sm:text-6xl",
			children: "Praktik Nikah"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto mt-8 max-w-md text-center text-xl leading-relaxed text-pretty",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Kepada Yth." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: penerimaKosong ? "text-2xl italic text-ink/65" : "text-2xl",
					children: tampilPenerima(detail)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-ink/70",
					children: "di tempat"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mx-auto mt-8 max-w-md text-center text-lg leading-relaxed text-pretty",
			children: "Assalamu'alaikum warahmatullahi wabarakatuh."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mx-auto mt-3 max-w-md text-center text-lg leading-relaxed text-pretty",
			children: "Dengan hormat, kami panitia mengundang Bapak/Ibu/Saudara/i untuk menghadiri acara Praktik Nikah yang insya Allah dilaksanakan pada:"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-10 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm tracking-crest uppercase text-ink/60",
					children: ACARA.hari
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-8xl leading-none",
					children: "5"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-2xl italic sm:text-3xl",
					children: "November 2026"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
			className: "mx-auto mt-10 grid max-w-md gap-6 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-sm tracking-crest uppercase text-ink/60",
					children: "Pukul"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: waktuKosong ? "mt-1 text-2xl italic text-ink/65" : "mt-1 text-2xl",
					children: tampilWaktu(detail)
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-sm tracking-crest uppercase text-ink/60",
					children: "Tempat"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: tempatKosong ? "mt-1 text-2xl italic text-ink/65 text-balance" : "mt-1 text-2xl text-balance",
					children: tampilTempat(detail)
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mx-auto mt-10 max-w-md text-center text-lg leading-relaxed text-pretty",
			children: "Kehadiran Bapak/Ibu/Saudara/i sangat kami nantikan. Atas perhatian dan kehadirannya, kami ucapkan terima kasih."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-center text-lg",
			children: "Wassalamu'alaikum warahmatullahi wabarakatuh."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-12 grid grid-cols-2 gap-6 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm tracking-wide text-ink/60",
					children: "Ketua"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mx-auto mt-10 block h-px w-24 bg-ink/30" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xl",
					children: "Johana Saputra"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-ink/60",
					children: "XII TKR 2"
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm tracking-wide text-ink/60",
					children: "Sekretaris"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mx-auto mt-10 block h-px w-24 bg-ink/30" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xl text-balance",
					children: "Ezra dan Aril"
				})
			] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-10 text-center text-sm tracking-wide text-ink/50",
			children: [instansi || "Panitia Praktik Nikah", " · Oktober 2026"]
		})
	] });
}
function Lampiran() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Bingkai, {
		id: "susunan",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-sm tracking-crest uppercase",
				children: "Lampiran"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 text-center text-4xl leading-tight text-balance italic sm:text-5xl",
				children: "Susunan Petugas"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-center text-lg text-ink/70",
				children: [
					ACARA.judul,
					" · ",
					ACARA.hari,
					", ",
					ACARA.tanggal
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Garis, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 space-y-10",
				children: KELOMPOK.map((kelompok) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-center text-sm tracking-crest uppercase text-ink/60",
					children: kelompok.judul
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3",
					children: kelompok.baris.map((baris) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-baseline justify-between gap-4 border-b border-ink/10 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm tracking-wide uppercase text-ink/55",
								children: baris.peran
							}), baris.kosong ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl italic text-ink/65",
								children: "Belum diisi"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl",
								children: baris.nama
							})]
						}), baris.kelas ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "shrink-0 text-right text-base text-ink/70",
							title: baris.jurusan,
							children: baris.kelas
						}) : null]
					}, `${kelompok.judul}-${baris.peran}-${baris.nama}`))
				})] }, kelompok.judul))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 text-center text-base leading-relaxed text-ink/60 text-pretty",
				children: "Nama dan kelas mengikuti catatan panitia. Bagian sungkem belum tertulis, jadi tidak dikarang."
			})
		]
	});
}
function Home() {
	const [detail, setDetail] = (0, import_react.useState)(DETAIL_AWAL);
	const [siap, setSiap] = (0, import_react.useState)(false);
	const [buka, setBuka] = (0, import_react.useState)(false);
	const [tersalin, setTersalin] = (0, import_react.useState)(false);
	const [teksGagal, setTeksGagal] = (0, import_react.useState)(false);
	const [sisaHari, setSisaHari] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setDetail(muatDetail());
		setSisaHari(hariMenuju(ACARA.iso));
		setSiap(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!siap) return;
		simpanDetail(detail);
	}, [detail, siap]);
	function ubah(kunci, nilai) {
		setDetail((sekarang) => ({
			...sekarang,
			[kunci]: nilai
		}));
	}
	async function bagikan() {
		const teks = buatTeks(detail);
		if (typeof navigator.share === "function") try {
			await navigator.share({
				title: "Undangan Praktik Nikah",
				text: teks
			});
			return;
		} catch (err) {
			if (err instanceof DOMException && err.name === "AbortError") return;
		}
		try {
			await navigator.clipboard.writeText(teks);
			setTersalin(true);
			setTeksGagal(false);
			window.setTimeout(() => setTersalin(false), 2200);
		} catch {
			setTeksGagal(true);
		}
	}
	const belumLengkap = detail.waktu.trim() === "" || detail.tempat.trim() === "";
	const hitung = sisaHari === null ? null : sisaHari > 0 ? `${sisaHari} hari lagi` : sisaHari === 0 ? "Hari ini" : "Telah berlalu";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen w-full max-w-3xl px-3 py-6 sm:px-6 sm:py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "no-print mb-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm tracking-crest uppercase text-paper/80",
						children: "Panitia"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-3xl leading-tight italic text-balance",
						children: "Undangan Praktik Nikah"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-lg text-paper/80",
						children: [
							ACARA.hari,
							", ",
							ACARA.tanggal,
							hitung ? ` · ${hitung}` : ""
						]
					}),
					belumLengkap ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-4 max-w-md text-base leading-relaxed text-paper/75 text-pretty",
						children: "Waktu dan tempat belum ada di catatan. Lengkapi dulu supaya undangannya siap dibagikan."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex flex-wrap items-center justify-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "inline-flex min-h-11 items-center gap-2 border border-gold/50 bg-gold px-4 text-lg text-ink",
								"aria-expanded": buka,
								onClick: () => setBuka((nilai) => !nilai),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Lengkapi"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#susunan",
								className: "inline-flex min-h-11 items-center gap-2 border border-gold/40 px-4 text-lg text-paper",
								children: "Susunan"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "inline-flex min-h-11 items-center gap-2 border border-gold/40 px-4 text-lg text-paper",
								onClick: () => void bagikan(),
								children: [tersalin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
									className: "size-4",
									"aria-hidden": "true"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, {
									className: "size-4",
									"aria-hidden": "true"
								}), tersalin ? "Tersalin" : "Bagikan"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "inline-flex min-h-11 items-center gap-2 border border-gold/40 px-4 text-lg text-paper",
								onClick: () => window.print(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Cetak"]
							})
						]
					})
				]
			}),
			buka ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "no-print sheet mx-auto mb-6 w-full max-w-2xl px-5 py-6 text-ink sm:px-8",
				onSubmit: (e) => e.preventDefault(),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm tracking-crest uppercase text-ink/60",
						children: "Detail undangan"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bidang, {
								label: "Ditujukan kepada",
								value: detail.penerima,
								placeholder: "Bapak/Ibu/Saudara/i",
								onChange: (nilai) => ubah("penerima", nilai)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bidang, {
								label: "Waktu",
								value: detail.waktu,
								placeholder: "contoh: 08.00 WIB",
								onChange: (nilai) => ubah("waktu", nilai)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bidang, {
								label: "Tempat",
								value: detail.tempat,
								placeholder: "contoh: Aula sekolah",
								onChange: (nilai) => ubah("tempat", nilai)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bidang, {
								label: "Sekolah atau instansi",
								value: detail.instansi,
								placeholder: "opsional, contoh: SMK …",
								onChange: (nilai) => ubah("instansi", nilai)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-base leading-relaxed text-ink/60",
						children: "Perubahan tersimpan di perangkat ini. Nama petugas diambil dari catatan dan tidak diubah di sini."
					})
				]
			}) : null,
			teksGagal ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "no-print sheet mx-auto mb-6 w-full max-w-2xl px-5 py-6 text-ink sm:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-lg",
					children: "Salin teks ini untuk dibagikan."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					readOnly: true,
					value: buatTeks(detail),
					className: "mt-3 h-64 w-full resize-none bg-transparent text-base leading-relaxed text-ink outline-none",
					onFocus: (e) => e.currentTarget.select()
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6 sm:space-y-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Surat, { detail }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lampiran, {})]
			})
		]
	});
}
function Bidang({ label, value, placeholder, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-sm tracking-crest uppercase text-ink/60",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value,
			placeholder,
			onChange: (e) => onChange(e.target.value),
			className: "mt-1 w-full border-b border-ink/20 bg-transparent py-2 text-2xl text-ink outline-none placeholder:text-ink/30 focus:border-gold"
		})]
	});
}
//#endregion
export { Home as component };
