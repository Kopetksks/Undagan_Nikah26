//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-5zGIm62m.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CsEMXjJC.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CsEMXjJC.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DIVfz61z.js"]
	}
} });
//#endregion
export { tsrStartManifest };
